package hn.edu.ujcv.pii.p2.objetos;

public interface IClase {
    double CalcularNotaFinal();
}
