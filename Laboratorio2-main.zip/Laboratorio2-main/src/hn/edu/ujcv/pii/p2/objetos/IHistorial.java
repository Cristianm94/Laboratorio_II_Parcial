package hn.edu.ujcv.pii.p2.objetos;

public interface IHistorial {
    double CalcularPromedio(double pro1);
}
